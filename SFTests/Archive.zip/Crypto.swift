//
//  Crypto.swift
//  SFTests
//
//  Created by Hasret Sariyer on 7.01.2021.
//

import Foundation

class Crypto {
    static func generateKeyPair(_ keySize: Int,_ algorihtm: String) -> Dictionary<String, Data?> {
        let publicKeyAttributes: [NSObject: NSObject] = [
                    kSecAttrIsPermanent: true as NSObject,
                    kSecAttrApplicationTag: "io.smartface.publicKeyA" as NSObject,
                    kSecClass: kSecClassKey,
                    kSecReturnData: kCFBooleanTrue
                ]
        let privateKeyAttributes: [NSObject: NSObject] = [
            kSecAttrIsPermanent: true as NSObject,
            kSecAttrApplicationTag: "io.smartface.privateKeyA" as NSObject,
            kSecClass: kSecClassKey,
            kSecReturnData: kCFBooleanTrue
        ]
        
        var _kSecAttrKeyType = kSecAttrKeyTypeRSA;
        if(algorihtm == "EC") {
            _kSecAttrKeyType = kSecAttrKeyTypeEC
        } else if(algorihtm == "ECSECPrimeRandom") {
            _kSecAttrKeyType = kSecAttrKeyTypeECSECPrimeRandom
        }
        
        let keypairAttributes: [NSObject: NSObject] = [
            kSecAttrKeyType: kSecAttrKeyTypeRSA,
            kSecAttrKeySizeInBits: keySize as NSObject,
            kSecPublicKeyAttrs: publicKeyAttributes as NSObject,
            kSecPrivateKeyAttrs: privateKeyAttributes as NSObject
        ]
        
        var publickey: SecKey?
        var privatekey: SecKey?
        let privatekeydata: Data?
        let publickeydata: Data?
        
        let status: OSStatus = SecKeyGeneratePair(keypairAttributes as CFDictionary, &publickey, &privatekey)
        
        if status == noErr && publickey != nil && privatekey != nil {
            var _publickey: AnyObject?
            var _privatekey: AnyObject?
            
            let statusPublic: OSStatus = SecItemCopyMatching(publicKeyAttributes as CFDictionary, &_publickey)
            let statusPrivate: OSStatus = SecItemCopyMatching(privateKeyAttributes as CFDictionary, &_privatekey)
            
            if statusPublic == noErr && statusPrivate == noErr {
                privatekeydata = _publickey as? Data
                publickeydata = _privatekey as? Data
                
                return ["public": publickeydata, "private": privatekeydata]
            }
        }
        return [:]
    }
    
    static func getX509FormattedKey(_ key: Data) -> Data {
        return key.dataByPrependingX509Header();
    }
    
    static func toBase64String(_ key: Data) -> String {
        return key.base64EncodedString()
    }
    
    static func decrypt(_ encryptedText: String,_ key: SecKey, _ algorithm: SecKeyAlgorithm) -> Data? {
        var error: Unmanaged<CFError>?
        let cfData: CFData = Data(encryptedText.utf8) as NSData as CFData

        guard SecKeyIsAlgorithmSupported(key, .decrypt, algorithm) else {
            fatalError("Can't use this algorithm with this key!")
        }
        if let decryptedCFData = SecKeyCreateDecryptedData(key, algorithm, cfData, &error) {
            return decryptedCFData as NSData as Data
        }
        
        if let err: Error = error?.takeRetainedValue() {
            fatalError("Error \(err.localizedDescription)")
        }
        return nil
    }
    
    static func encrypt(plainText: String,_ key: SecKey,_ algorithm: SecKeyAlgorithm) -> String? {
        var error: Unmanaged<CFError>?
        let data = Data(plainText.utf8)
        let cfData: CFData = data as NSData as CFData
        
        if let encryptedCFData = SecKeyCreateEncryptedData(key, algorithm, cfData, &error) {
            let myData = encryptedCFData as NSData as Data
            let str = String(decoding: myData, as: UTF8.self)
            print("encryptedData \(str)")
            return str
        }
        if let err: Error = error?.takeRetainedValue() {
            fatalError("Error \(err.localizedDescription)")
        }
        return nil
    }
    
    static func getKeyFromBase64String(encodedKey: String, isPrivate: Bool = false, keySize: Int) -> SecKey? {
        var keyClass = kSecAttrKeyClassPublic
        if isPrivate {
            keyClass = kSecAttrKeyClassPrivate
        }
        let attributes: [String:Any] =
        [
            kSecAttrKeyClass as String: keyClass,
            kSecAttrKeyType as String: kSecAttrKeyTypeRSA,
            kSecAttrKeySizeInBits as String: keySize,
        ]

        guard let secKeyData = Data.init(base64Encoded: encodedKey) else {
            print("Error: invalid encodedKey, cannot extract data")
            return nil
        }
        guard let secKey = SecKeyCreateWithData(secKeyData as CFData, attributes as CFDictionary, nil) else {
            print("Error: Problem in SecKeyCreateWithData()")
            return nil
        }

        return secKey
    }
}

private extension NSInteger {
    func encodedOctets() -> [CUnsignedChar] {
        // Short form
        if self < 128 {
            return [CUnsignedChar(self)];
        }
        
        // Long form
        let i = Int(log2(Double(self)) / 8 + 1)
        var len = self
        var result: [CUnsignedChar] = [CUnsignedChar(i + 0x80)]
        
        for _ in 0..<i {
            result.insert(CUnsignedChar(len & 0xFF), at: 1)
            len = len >> 8
        }
        
        return result
    }
    
    init?(octetBytes: [CUnsignedChar], startIdx: inout NSInteger) {
        if octetBytes[startIdx] < 128 {
            // Short form
            self.init(octetBytes[startIdx])
            startIdx += 1
        } else {
            // Long form
            let octets = NSInteger(octetBytes[startIdx] as UInt8 - 128)
            
            if octets > octetBytes.count - startIdx {
                self.init(0)
                return nil
            }
            
            var result = UInt64(0)
            
            for j in 1...octets {
                result = (result << 8)
                result = result + UInt64(octetBytes[startIdx + j])
            }
            
            startIdx += 1 + octets
            self.init(result)
        }
    }
}

extension Data {
  public func dataByPrependingX509Header() -> Data {
      let result = NSMutableData()

      let encodingLength: Int = (self.count + 1).encodedOctets().count
      let OID: [CUnsignedChar] = [0x30, 0x0d, 0x06, 0x09, 0x2a, 0x86, 0x48, 0x86,
          0xf7, 0x0d, 0x01, 0x01, 0x01, 0x05, 0x00]

      var builder: [CUnsignedChar] = []

      // ASN.1 SEQUENCE
      builder.append(0x30)

      // Overall size, made of OID + bitstring encoding + actual key
      let size = OID.count + 2 + encodingLength + self.count
    
      let encodedSize = size.encodedOctets()
      builder.append(contentsOf: encodedSize)
      result.append(builder, length: builder.count)
      result.append(OID, length: OID.count)
      builder.removeAll(keepingCapacity: false)

      builder.append(0x03)
      builder.append(contentsOf: (self.count + 1).encodedOctets())
      builder.append(0x00)
      result.append(builder, length: builder.count)

      // Actual key bytes
      result.append(self)

      return result as Data
  }
}
